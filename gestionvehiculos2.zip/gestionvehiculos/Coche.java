/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionvehiculos;

/**
 *
 * @author gonzalo.rueda1
 */
// Subclase 'Coche' que hereda de 'Vehiculo' usando la palabra clave extends
public class Coche extends Vehiculo {    
    private int numeroPuertas; // Atributo exclusivo de la clase Coche

    // Constructor de Coche
    public Coche(String marca, String modelo, int anio, double precioDia, int numeroPuertas) {        
        // super(): Invoca al constructor de la clase padre (Vehiculo) para inicializar sus atributos
        super(marca, modelo, anio, precioDia);        
        this.numeroPuertas = numeroPuertas;    
    }    

    // Getter y Setter específicos para el número de puertas
    public int getNumeroPuertas()              { return numeroPuertas; }    
    public void setNumeroPuertas(int puertas) { this.numeroPuertas = puertas; }    

    @Override // Indica que estamos sobrescribiendo (modificando) el método de la clase padre
    public void mostrarInformacion() {        
        super.mostrarInformacion(); // Llama al método original del padre para reutilizar su código
        System.out.println("Puertas: " + numeroPuertas); // Añade el dato específico del coche
    }
}