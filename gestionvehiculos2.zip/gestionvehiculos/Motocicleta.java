/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionvehiculos;

/**
 *
 * @author gonzalo.rueda1
 */
// Subclase 'Motocicleta' que hereda de 'Vehiculo'
public class Motocicleta extends Vehiculo {    
    private boolean tieneMaletero; // Atributo exclusivo de la clase Motocicleta

    // Constructor de Motocicleta
    public Motocicleta(String marca, String modelo, int anio, double precioDia, boolean tieneMaletero) {        
        // Invoca al constructor de la clase padre
        super(marca, modelo, anio, precioDia);        
        this.tieneMaletero = tieneMaletero;    
    }    

    // Getter y Setter específicos para el maletero
    public boolean isTieneMaletero()              { return tieneMaletero; }    
    public void setTieneMaletero(boolean maletero) { this.tieneMaletero = maletero; }    

    @Override // Sobrescribe el método del padre
    public void mostrarInformacion() {        
        super.mostrarInformacion(); // Imprime la información común (marca, modelo, etc.)
        // Uso de un operador ternario para transformar el booleano en "Sí" o "No"
        System.out.println("Maletero: " + (tieneMaletero ? "Sí" : "No"));    
    }
}