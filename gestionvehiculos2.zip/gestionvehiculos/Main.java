/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionvehiculos;

/**
 *
 * @author gonzalo.rueda1
 */
import java.util.ArrayList;

public class Main {    
    public static void main(String[] args) {        
        // Lista Polimórfica: Al ser de tipo 'Vehiculo', puede almacenar tanto Coches como Motocicletas
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();        

        // Añadimos diferentes objetos hijos a la lista común
        vehiculos.add(new Coche("Toyota",  "Corolla", 2022, 45.0, 5));        
        vehiculos.add(new Coche("Ford",    "Focus",   2020, 38.0, 3));        
        vehiculos.add(new Motocicleta("Yamaha", "MT-07",     2021, 30.0, false));        
        vehiculos.add(new Motocicleta("Honda",  "CB500F",    2023, 25.0, true));        

        // Recorremos la lista usando un bucle for-each
        for (Vehiculo v : vehiculos) {            
            // POLIMORFISMO: Java detecta automáticamente en tiempo de ejecución qué tipo de objeto es 
            // (Coche o Moto) y ejecuta la versión correcta del método mostrarInformacion().
            v.mostrarInformacion();       
            System.out.println("-------------------");        
        }    
    }
}